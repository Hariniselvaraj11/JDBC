/**
 * 
 */
/**
 * 
 */
module vehiclejdbc {
	requires java.sql;
}