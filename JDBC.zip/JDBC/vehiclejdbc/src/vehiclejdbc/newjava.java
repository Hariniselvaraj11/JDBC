package vehiclejdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class newjava {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/vehicledb";
        String user = "root";
        String password = "Mysql@2026";

        Scanner sc = new Scanner(System.in);

        try {

            Connection con = DriverManager.getConnection(url, user, password);
            System.out.println("Connection Successful");

            System.out.println("\n1. Insert Vehicle");
            System.out.println("2. Get All Vehicles");
            System.out.println("3. Get Vehicle By ID");
            System.out.println("4. Get Vehicle By Make");
            System.out.println("5. Update Vehicle");
            System.out.println("6. Delete Vehicle");
            System.out.println("0. Exit");

            System.out.print("Enter Choice : ");
            int choice = sc.nextInt();

            if (choice == 0) {
                System.out.println("Thank You");
                con.close();
                sc.close();
                return;
            }

            switch (choice) {

            case 1:

                PreparedStatement p = con.prepareStatement(
                        "insert into vehicle values(?,?,?,?)");

                System.out.print("Enter Id : ");
                p.setInt(1, sc.nextInt());

                System.out.print("Enter Year : ");
                p.setInt(2, sc.nextInt());

                sc.nextLine();

                System.out.print("Enter Model : ");
                p.setString(3, sc.nextLine());

                System.out.print("Enter Make : ");
                p.setString(4, sc.nextLine());

                int a = p.executeUpdate();

                if (a > 0)
                    System.out.println("Vehicle Inserted");
                else
                    System.out.println("Not Inserted");

                break;

            case 2:

                Statement st = con.createStatement();

                ResultSet rs = st.executeQuery("select * from vehicle");

                while (rs.next()) {

                    System.out.println(rs.getInt("id") + " "+ rs.getInt("year") + " "+ rs.getString("model") + " "+ rs.getString("make"));
                }

        

                break;

            case 3:

                PreparedStatement p1 = con.prepareStatement(
                        "select * from vehicle where id=?");

                System.out.print("Enter Id : ");
                p1.setInt(1, sc.nextInt());

                ResultSet r1 = p1.executeQuery();

                while(r1.next()) {

                    System.out.println(
                            r1.getInt("id") + " "+ r1.getInt("year") + " "+ r1.getString("model") + " "+ r1.getString("make"));

                            
                }                

                break;

            case 4:

                sc.nextLine();

                PreparedStatement p2 = con.prepareStatement(
                        "select * from vehicle where make=?");

                System.out.print("Enter Make : ");
                p2.setString(1, sc.nextLine());

                ResultSet r2 = p2.executeQuery();

                while (r2.next()) {

                    System.out.println(
                            r2.getInt("id") + " "
                            + r2.getInt("year") + " "
                            + r2.getString("model") + " "
                            + r2.getString("make"));
                }

                break;

            case 5:

                PreparedStatement p3 = con.prepareStatement(
                        "update vehicle set year=?,model=?,make=? where id=?");

                System.out.print("Enter Id : ");
                int id = sc.nextInt();

                System.out.print("Enter New Year : ");
                int year = sc.nextInt();

                sc.nextLine();

                System.out.print("Enter New Model : ");
                String model = sc.nextLine();

                System.out.print("Enter New Make : ");
                String make = sc.nextLine();

                p3.setInt(1, year);
                p3.setString(2, model);
                p3.setString(3, make);
                p3.setInt(4, id);

                int b = p3.executeUpdate();

                if (b > 0)
                    System.out.println("Vehicle Updated");
                else
                    System.out.println("Record Not Found");

                break;

            case 6:

                PreparedStatement p4 = con.prepareStatement(
                        "delete from vehicle where id=?");

                System.out.print("Enter Id : ");
                p4.setInt(1, sc.nextInt());

                int c = p4.executeUpdate();

                if (c > 0)
                    System.out.println("Vehicle Deleted");
                else
                    System.out.println("Record Not Found");

                break;

            
            }

            con.close();
            sc.close();

        } catch(SQLException e){
    		System.out.println("Connection failed"+ e.getMessage());
        }
    }
}